﻿Sanya Sinha
David Woolston
Jackson Davis


TCSS-504 Iteration 3 ReadMe

So Far:
* No issues encountered. 


* Things are going smoothly, we’ve got a running GUI with intuitive menus and a randomized maze / dungeon. 



Our next steps are:
* Inserting monsters and items into the map (99% there!)


* Saving / Loading games (In Progress)


* Reading parameters in from the Database (Success!)


* Combat System -> Iteration 3 project

﻿Sanya Sinha
David Woolston
Jackson Davis


TCSS-504 Iteration 1 ReadMe

So Far:
* No issues encountered. 


* Things are going smoothly, we’ve got a running GUI with intuitive menus and a randomized maze / dungeon. 




Our next steps are:
* Inserting monsters and items into the map


* Saving / Loading games


* Reading parameters in from the Database
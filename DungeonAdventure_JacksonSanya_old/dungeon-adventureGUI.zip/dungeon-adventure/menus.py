"""
Menu UI classes:

Intro Menu

"""


class Menu:

    def __init__(self):
        pass

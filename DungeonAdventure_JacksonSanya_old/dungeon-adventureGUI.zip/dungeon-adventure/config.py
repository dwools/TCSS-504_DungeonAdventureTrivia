# Constant Variables

# Window Dimensions
WIN_WIDTH = 1280
WIN_HEIGHT = 960
WINDOW_SIZE = (WIN_WIDTH, WIN_HEIGHT)

# COLOR = (r, g, b)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
PURPLE = (11, 0, 11)

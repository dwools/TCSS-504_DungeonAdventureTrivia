Sanya Sinha
David Woolston
Jackson Davis

TCSS-504 Iteratoin 4 ReadMe

So far:

 * Having issues saving.

 * We are on a time crunch due to saving difficulty, and similar difficulty is likely in figuring out loading a new game. Items are relatively okay, but need finalization and integration with player character. 


Our next steps are: 
 * Saving / loading games (still in progress)

 * Combat system (still in progress)

 * Items (still in progress)